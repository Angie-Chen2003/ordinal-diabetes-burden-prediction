#!/bin/bash
# ============================================================
# run_hpc_bca_pooled.sh  -- submit BCa for the two pooled datasets
# ------------------------------------------------------------
# Single job, multi-core (mclapply). Runs Pool + Balanced_Pool_200.
# Submit from /scratch/xw3922/HPC_code/R_script/ :
#     sbatch run_hpc_bca_pooled.sh
# Check status:   squeue -u xw3922
# Watch log:      tail -f bca_pooled_<jobid>.out
# ============================================================
#SBATCH --job-name=bca_pooled
#SBATCH --account=torch_pr_525_general
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=12:00:00
#SBATCH --output=bca_pooled_%j.out
#SBATCH --error=bca_pooled_%j.err

set -e

echo "Job started: $(date)"
echo "Host: $(hostname)"
echo "CPUs per task: ${SLURM_CPUS_PER_TASK}"

# Load R
module purge
module load r/4.5.1

# Personal library (where ordinalForest/mildsvm/kknn/etc. are installed)
export R_LIBS_USER=/scratch/xw3922/R_libs

# Run from the R_script directory so source("00_functions_data.R") works
cd /scratch/xw3922/HPC_code/R_script

echo "Running 09_hpc_bca_pooled.R ..."
Rscript 09_hpc_bca_pooled.R

echo "Job finished: $(date)"
