# ============================================================
# 11_export_bca_tables.R  -- merge all 10 BCa RDS + health check + export Excel
# ------------------------------------------------------------
# Reads the 10 per-dataset <label>_BCa_full.rds files produced by
# 09_bca_all_datasets.R (8 single countries) and 10_hpc_bca_pooled.r
# (Pool, Balanced_Pool_200), merges them, runs an automated HEALTH CHECK that
# flags suspicious CIs, and exports user-facing Excel tables.
#
# HEALTH CHECK flags (so silly results cannot hide in the table):
#   - REVERSED   : BCa_Lower > BCa_Upper
#   - EXCLUDES_PE: Original point estimate not inside [Lower, Upper]
#   - OUT_OF_RANGE: bound < 0 or > 1 for bounded metrics (AUC-type: ORC/GC/ADC/Accuracy/Macro_F1/MZOE)
#   - COLLAPSED  : Lower == Upper (CI is a single point; may be real, verify)
#   - EXTREME_Z0 : |z0| > 2  (bias correction extreme)
#   - EXTREME_A  : |a|  > 0.5 (acceleration extreme)
#   - NA_CI      : Lower or Upper is NA
# Each row gets a Health_Flags column (comma-joined) and an OK/CHECK status.
#
# Output: Output_new/ALL_datasets_BCa.xlsx  with sheets:
#   - BCa_All           : every row (all datasets/models/splits/metrics) + flags
#   - BCa_Test_Main     : Test split, 6 main metrics, paper format "est [lo, up]"
#   - Health_Check_FLAGS: ONLY the rows that got flagged (your review list)
#
# Usage: setwd("~/Documents/Jeannette/HPC_code/R_script"); source("11_export_bca_tables.r")
# ============================================================

suppressMessages({
  library(dplyr)
  library(writexl)
})

OUTPUT_NEW <- "~/Documents/Jeannette/HPC_code/Output_new"

dataset_labels <- c("CHARLS", "HRS", "KLoSA", "LASI", "MAHS",
                    "SA", "SHARE", "UK", "Pool", "Balanced_Pool_200")

main_metrics    <- c("Accuracy", "Macro_F1", "ORC", "GC", "ADC", "Macro_MAE")
bounded_metrics <- c("Accuracy", "Macro_F1", "MZOE", "ORC", "GC", "ADC")  # should be within [0,1]

# ============================================================
# 1. Load and merge all 10 BCa tables
# ============================================================
cat("Loading 10 BCa RDS files...\n")
all_list <- list()
for (lab in dataset_labels) {
  f <- file.path(OUTPUT_NEW, lab, paste0(lab, "_BCa_full.rds"))
  if (!file.exists(f)) { cat("  !!! MISSING:", f, "\n"); next }
  obj <- readRDS(f)
  if (is.null(obj$bca_table)) { cat("  !!! no bca_table in", lab, "\n"); next }
  all_list[[lab]] <- obj$bca_table
  cat("  loaded", lab, "(", nrow(obj$bca_table), "rows )\n")
}
bca_all <- bind_rows(all_list)
cat("Merged:", nrow(bca_all), "total rows from", length(all_list), "datasets.\n\n")

# ============================================================
# 2. Health check -- flag suspicious CIs
# ============================================================
cat("Running health check...\n")

flag_row <- function(metric, original, lower, upper, z0, a) {
  flags <- c()
  if (is.na(lower) || is.na(upper)) flags <- c(flags, "NA_CI")
  if (!is.na(lower) && !is.na(upper)) {
    if (lower > upper) flags <- c(flags, "REVERSED")
    if (lower == upper) flags <- c(flags, "COLLAPSED")
    if (!is.na(original) && (original < min(lower, upper) - 1e-9 || original > max(lower, upper) + 1e-9))
      flags <- c(flags, "EXCLUDES_PE")
    if (metric %in% bounded_metrics) {
      if (lower < -1e-9 || upper < -1e-9 || lower > 1 + 1e-9 || upper > 1 + 1e-9)
        flags <- c(flags, "OUT_OF_RANGE")
    }
  }
  if (!is.na(z0) && abs(z0) > 2)   flags <- c(flags, "EXTREME_Z0")
  if (!is.na(a)  && abs(a)  > 0.5) flags <- c(flags, "EXTREME_A")
  paste(flags, collapse = ", ")
}

bca_all$Health_Flags <- mapply(flag_row,
                               bca_all$Metric, bca_all$Original, bca_all$BCa_Lower, bca_all$BCa_Upper,
                               bca_all$z0, bca_all$a, SIMPLIFY = TRUE, USE.NAMES = FALSE)
bca_all$Status <- ifelse(bca_all$Health_Flags == "", "OK", "CHECK")

n_flagged <- sum(bca_all$Status == "CHECK")
cat("  flagged rows:", n_flagged, "of", nrow(bca_all), "\n")

# summary of flag types
if (n_flagged > 0) {
  all_flags <- unlist(strsplit(bca_all$Health_Flags[bca_all$Status=="CHECK"], ", "))
  cat("  flag breakdown:\n")
  for (ft in names(sort(table(all_flags), decreasing = TRUE)))
    cat(sprintf("    %-14s %d\n", ft, sum(all_flags == ft)))
}
cat("\n")

# ============================================================
# 3. Paper-format Test table (6 main metrics, "est [lo, up]")
# ============================================================
fmt_ci <- function(est, lo, up) {
  if (is.na(est)) return(NA_character_)
  if (is.na(lo) || is.na(up)) return(sprintf("%.3f [NA]", est))
  sprintf("%.3f [%.3f, %.3f]", est, lo, up)
}

test_main <- bca_all %>%
  filter(Dataset == "Test", Metric %in% main_metrics) %>%
  mutate(Estimate_CI = mapply(fmt_ci, Original, BCa_Lower, BCa_Upper)) %>%
  dplyr::select(Country, Model, Metric, Estimate_CI, Health_Flags)

# wide view: one row per Country x Model, columns = 6 metrics
test_main_wide <- test_main %>%
  dplyr::select(Country, Model, Metric, Estimate_CI) %>%
  tidyr::pivot_wider(names_from = Metric, values_from = Estimate_CI) %>%
  dplyr::select(Country, Model, all_of(main_metrics))

# ============================================================
# 4. Flagged-only sheet (your review list)
# ============================================================
flagged_only <- bca_all %>% filter(Status == "CHECK") %>%
  dplyr::select(Country, Model, Dataset, Metric, Original, BCa_Lower, BCa_Upper, z0, a, Health_Flags)

# ============================================================
# 5. Export
# ============================================================
out_path <- file.path(OUTPUT_NEW, "ALL_datasets_BCa.xlsx")
writexl::write_xlsx(
  list(
    BCa_All            = bca_all,
    BCa_Test_Main      = test_main_wide,
    Health_Check_FLAGS = flagged_only
  ),
  path = out_path
)

cat("==================== EXPORT DONE ====================\n")
cat("Saved:", out_path, "\n")
cat("Sheets:\n")
cat("  BCa_All            -", nrow(bca_all), "rows (everything + Health_Flags + Status)\n")
cat("  BCa_Test_Main      -", nrow(test_main_wide), "rows (Test, 6 main metrics, paper format)\n")
cat("  Health_Check_FLAGS -", nrow(flagged_only), "rows (ONLY flagged -- review these)\n\n")

if (n_flagged > 0) {
  cat(">>> ", n_flagged, " rows flagged. Open the Health_Check_FLAGS sheet first.\n", sep="")
  cat(">>> Many flags may be expected (e.g. logit Accuracy COLLAPSED, known KNN ADC).\n")
  cat(">>> Send me the Health_Check_FLAGS sheet and we'll triage which are real.\n")
} else {
  cat(">>> No rows flagged -- all CIs passed the health check.\n")
}