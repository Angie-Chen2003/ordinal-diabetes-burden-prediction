# ============================================================
# 12_bca_pool_to_country.R  -- BCa for pooled-model generalization to each country
# ------------------------------------------------------------
# Adds BCa 95% CIs to the "pooled model -> each country" generalization results
# (the analysis in script 08), evaluated on each country's TEST set -- the SAME
# test split used by the cohort-specific analysis (team decision).
#
# IMPORTANT design points to stay correct:
#  (1) The pooled model expects Pool-format predictors: it KEEPS social_eco_ppp,
#      drops social_eco, and uses country_factor. So we must build each country's
#      data in Pool format (like script 08) -- NOT reuse 00's single-country
#      test_ord, which DROPS social_eco_ppp.
#  (2) To get the SAME test rows as the cohort-specific split, we reproduce 00's
#      exact preprocessing ORDER and the SAME split call:
#         set.seed(123); createDataPartition(burden_score_ord, p=0.8)
#      Because the row filtering (drop NA pain/vision; keep burden 0/1/2) matches
#      00, the resulting test indices match the cohort-specific test set.
#      A SELF-CHECK prints each country's test n (CHARLS must be 424).
#
# For each (source model in {Pool, Balanced_Pool_200}) x country x 4 R models:
#   fixed pooled-model prediction on that country's test set -> original
#   prediction-level jackknife (model fixed) -> a
#   same-source fixed-margin bootstrap (seed = BOOT_SEED_BASE + b) -> z0
#   BCa CI for all 9 metrics.
#
# Local run. Usage: setwd(".../R_script"); source("12_bca_pool_to_country.r")
# ============================================================

suppressMessages({
  library(readxl); library(dplyr); library(caret); library(pROC)
  library(MASS); library(ordinalForest); library(mildsvm); library(kknn)
  library(writexl); library(tidyr)
})

HPC_ROOT    <- "~/Documents/Jeannette/HPC_code"
DATASET_DIR <- file.path(HPC_ROOT, "Dataset")
OUTPUT_DIR  <- file.path(HPC_ROOT, "Output")
RSCRIPT_DIR <- file.path(HPC_ROOT, "R_script")

BOOT_SEED_BASE <- 123
B_BOOT         <- 1000
SPLIT_SEED     <- 123   # must match 00's split seed

metric_names <- c("Accuracy", "Macro_F1", "MAE", "MSE", "MZOE",
                  "Macro_MAE", "ORC", "GC", "ADC")

# Need 00's helper functions (calc_ordinal_metrics, eval_ordinal_model, align_prob_matrix,
# make_scaled_* ...). Source 00 ONCE with a single-country config just to load the
# helper functions into the global env. We will NOT use its split; we do our own.
country_label  <<- "CHARLS"
data_path      <<- file.path(DATASET_DIR, "CHARLS_final.xlsx")
output_dir     <<- file.path(OUTPUT_DIR, "CHARLS")
cols_to_remove <<- c("social_eco_ppp", "country")
setwd(RSCRIPT_DIR)
source(file.path(RSCRIPT_DIR, "00_functions_data.r"))  # loads helper functions (+ builds CHARLS objects we ignore)

# country -> data file + Pool country_factor value
country_configs <- list(
  list(name = "CHARLS", file = "CHARLS_final.xlsx", cf = "China"),
  list(name = "HRS",    file = "HRS_final.xlsx",    cf = "United States"),
  list(name = "KLoSA",  file = "KLoSA_final.xlsx",  cf = "Korea"),
  list(name = "LASI",   file = "LASI_final.xlsx",   cf = "India"),
  list(name = "MAHS",   file = "MAHS_final.xlsx",   cf = "Mexico"),
  list(name = "SA",     file = "SA_final.xlsx",     cf = "South Africa"),
  list(name = "SHARE",  file = "SHARE_final.xlsx",  cf = "Europe"),
  list(name = "UK",     file = "UK_final.xlsx",     cf = "UK")
)
pool_country_levels <- c("China", "United States", "Korea", "India",
                         "Mexico", "South Africa", "Europe", "UK")

source_models <- list(
  list(label = "Pool",              dir = file.path(OUTPUT_DIR, "Pool")),
  list(label = "Balanced_Pool_200", dir = file.path(OUTPUT_DIR, "Balanced_Pool_200"))
)

# ============================================================
# Build one country's TEST set in POOL format, with the SAME rows as the
# cohort-specific test split.
# Mirrors 00's preprocessing ORDER exactly so the split lines up, but keeps
# social_eco_ppp (drops social_eco) and uses country_factor -- Pool format.
# ============================================================
build_country_test_pool_format <- function(cfg) {
  raw <- read_xlsx(file.path(DATASET_DIR, cfg$file))
  
  # --- reproduce 00's row filtering & outcome construction EXACTLY (order matters) ---
  d <- raw %>%
    mutate(pain = as.numeric(as.character(pain)),
           vision = as.numeric(as.character(vision))) %>%
    filter(!is.na(pain), !is.na(vision)) %>%
    mutate(burden_score = pain + vision) %>%
    filter(burden_score %in% c(0, 1, 2))
  d$burden_score_ord <- factor(d$burden_score, levels = c(0,1,2), ordered = TRUE)
  d$burden_score_int <- as.integer(d$burden_score_ord) - 1
  
  # --- SAME split as 00: set.seed(123); createDataPartition(burden_score_ord, 0.8) ---
  set.seed(SPLIT_SEED)
  trainIndex <- caret::createDataPartition(d$burden_score_ord, p = 0.8, list = FALSE)
  test_rows  <- d[-trainIndex, ]   # the held-out test set (matches cohort-specific)
  
  # --- now convert the TEST rows to Pool format ---
  # drop outcome components + social_eco (Pool keeps social_eco_ppp), drop raw country
  drop_cols <- intersect(c("pain", "vision", "social_eco", "country"), names(test_rows))
  tp <- test_rows[, setdiff(names(test_rows), drop_cols), drop = FALSE]
  # add country_factor (single level for this country, full Pool levels for factor)
  tp$country_factor <- factor(cfg$cf, levels = pool_country_levels)
  
  tp
}

# ============================================================
# Helpers (BCa machinery -- identical to 09/10/11)
# ============================================================
make_stratified_boot_index <- function(y, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  y <- factor(y, levels = levels(y), ordered = TRUE)
  ib <- split(seq_along(y), y)
  unlist(lapply(ib, function(idx) sample(idx, length(idx), replace = TRUE)), use.names = FALSE)
}
compute_bca <- function(boot_vals, theta_hat, jack_vals, alpha = 0.05) {
  boot_vals <- boot_vals[!is.na(boot_vals)]; B <- length(boot_vals)
  if (B < 10 || is.na(theta_hat)) return(list(lower=NA, upper=NA, z0=NA, a=NA, note="insufficient data"))
  pl <- mean(boot_vals < theta_hat)
  if (pl <= 0) pl <- 1/(2*B); if (pl >= 1) pl <- 1 - 1/(2*B)
  z0 <- qnorm(pl)
  jv <- jack_vals[!is.na(jack_vals)]
  if (length(jv) < 3) { a <- 0; note <- "insufficient jackknife, a=0" }
  else { jm <- mean(jv); df <- jm - jv; den <- 6*(sum(df^2))^1.5; a <- if (den==0) 0 else sum(df^3)/den; note <- "" }
  zl <- qnorm(alpha/2); zh <- qnorm(1-alpha/2)
  adj <- function(zb) pnorm(z0 + (z0+zb)/(1 - a*(z0+zb)))
  list(lower = as.numeric(quantile(boot_vals, adj(zl), na.rm=TRUE, names=FALSE)),
       upper = as.numeric(quantile(boot_vals, adj(zh), na.rm=TRUE, names=FALSE)),
       z0 = z0, a = a, note = note)
}

# ============================================================
# Process one (source model, country)
# ============================================================
process_src_country <- function(src, cfg, tm) {
  preProc <- tm$preProc; outcome_levels <- tm$outcome_levels
  test_pool <- build_country_test_pool_format(cfg)
  
  # SELF-CHECK: print test n (CHARLS must be 424)
  cat(sprintf("    [%s -> %s] test n = %d\n", src$label, cfg$name, nrow(test_pool)))
  
  y_true <- factor(test_pool$burden_score_ord, levels = outcome_levels, ordered = TRUE)
  x_cols <- setdiff(names(test_pool), c("burden_score","burden_score_ord","burden_score_int"))
  x_new  <- test_pool[, x_cols, drop = FALSE]
  x_sc   <- predict(preProc, x_new)
  
  preds <- list()
  preds[["Ordinal Logistic Regression"]] <- tryCatch(list(mt="prob",
                                                          pred = factor(predict(tm$model_logit, newdata=x_sc, type="class"), levels=outcome_levels, ordered=TRUE),
                                                          prob = align_prob_matrix(predict(tm$model_logit, newdata=x_sc, type="probs"), outcome_levels)),
                                                     error=function(e){message("  logit ",cfg$name,": ",e$message);NULL})
  preds[["Ordinal Forest"]] <- tryCatch({po<-predict(tm$model_forest,newdata=x_sc); list(mt="prob",
                                                                                         pred = factor(po$ypred, levels=outcome_levels, ordered=TRUE),
                                                                                         prob = align_prob_matrix(po$classprobs, outcome_levels))},
                                        error=function(e){message("  forest ",cfg$name,": ",e$message);NULL})
  preds[["Ordinal SVM"]] <- tryCatch({pc<-predict(tm$model_svm,new_data=x_sc,type="class")
  rw<-predict(tm$model_svm,new_data=x_sc,type="raw"); list(mt="score",
                                                           pred = factor(pc$.pred_class, levels=outcome_levels, ordered=TRUE),
                                                           score = as.numeric(as.data.frame(rw)[[1]]))},
  error=function(e){message("  svm ",cfg$name,": ",e$message);NULL})
  preds[["Ordinal KNN"]] <- tryCatch(list(mt="prob",
                                          pred = factor(predict(tm$model_knn, newdata=x_sc, type="raw"), levels=outcome_levels, ordered=TRUE),
                                          prob = align_prob_matrix(predict(tm$model_knn, newdata=x_sc, type="prob"), outcome_levels)),
                                     error=function(e){message("  knn ",cfg$name,": ",e$message);NULL})
  preds <- preds[!sapply(preds, is.null)]
  if (length(preds) == 0) return(NULL)
  
  metric_vec <- function(po, idx) {
    ys <- factor(y_true[idx], levels=outcome_levels, ordered=TRUE)
    ps <- factor(po$pred[idx], levels=outcome_levels, ordered=TRUE)
    cm <- tryCatch(caret::confusionMatrix(ps, ys), error=function(e) NULL)
    if (is.null(cm)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    om <- if (po$mt=="prob") tryCatch(calc_ordinal_metrics(ys, po$prob[idx,,drop=FALSE]), error=function(e) NULL)
    else tryCatch(calc_ordinal_metrics_from_score(ys, po$score[idx]), error=function(e) NULL)
    if (is.null(om)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    ev <- eval_ordinal_model("tmp", ys, ps, cm, om)
    setNames(as.numeric(ev[1, metric_names]), metric_names)
  }
  
  rows <- list()
  for (mname in names(preds)) {
    po <- preds[[mname]]; n <- length(y_true)
    orig <- metric_vec(po, seq_len(n))
    jm <- matrix(NA_real_, n, length(metric_names), dimnames=list(NULL, metric_names))
    for (i in seq_len(n)) jm[i, ] <- metric_vec(po, setdiff(seq_len(n), i))
    bm <- matrix(NA_real_, B_BOOT, length(metric_names), dimnames=list(NULL, metric_names))
    for (b in seq_len(B_BOOT)) bm[b, ] <- metric_vec(po, make_stratified_boot_index(y_true, BOOT_SEED_BASE + b))
    for (mt in metric_names) {
      res <- compute_bca(bm[, mt], orig[[mt]], jm[, mt])
      rows[[length(rows)+1]] <- data.frame(Source=src$label, Country=cfg$name, Model=mname, Metric=mt,
                                           Original=round(orig[[mt]],4), BCa_Lower=round(res$lower,4), BCa_Upper=round(res$upper,4),
                                           z0=round(res$z0,4), a=round(res$a,4), Note=res$note, stringsAsFactors=FALSE)
    }
  }
  do.call(rbind, rows)
}

# ============================================================
# Run
# ============================================================
cat("BCa: pooled-model generalization to each country (test sets)\n")
cat("SELF-CHECK: CHARLS test n should be 424 (matches cohort-specific split)\n\n")
all_rows <- list()
for (src in source_models) {
  cat("#### Source:", src$label, "####\n")
  tm <- readRDS(file.path(src$dir, "trained_models.rds"))
  for (cfg in country_configs) {
    res <- tryCatch(process_src_country(src, cfg, tm),
                    error=function(e){message(">>> ",src$label,"->",cfg$name," ERROR: ",e$message);NULL})
    if (!is.null(res)) all_rows[[paste(src$label, cfg$name)]] <- res
  }
}
bca_gen <- do.call(rbind, all_rows)

# Health check
bounded <- c("Accuracy","Macro_F1","MZOE","ORC","GC","ADC")
flag_row <- function(metric, original, lower, upper, z0, a) {
  f <- c()
  if (is.na(lower)||is.na(upper)) f <- c(f,"NA_CI")
  if (!is.na(lower)&&!is.na(upper)) {
    if (lower>upper) f <- c(f,"REVERSED")
    if (lower==upper) f <- c(f,"COLLAPSED")
    if (!is.na(original)&&(original<min(lower,upper)-1e-9||original>max(lower,upper)+1e-9)) f <- c(f,"EXCLUDES_PE")
    if (metric%in%bounded&&(lower< -1e-9||upper>1+1e-9)) f <- c(f,"OUT_OF_RANGE")
  }
  if (!is.na(z0)&&abs(z0)>2) f <- c(f,"EXTREME_Z0")
  if (!is.na(a)&&abs(a)>0.5) f <- c(f,"EXTREME_A")
  paste(f, collapse=", ")
}
bca_gen$Health_Flags <- mapply(flag_row, bca_gen$Metric, bca_gen$Original,
                               bca_gen$BCa_Lower, bca_gen$BCa_Upper, bca_gen$z0, bca_gen$a, USE.NAMES=FALSE)
bca_gen$Status <- ifelse(bca_gen$Health_Flags=="", "OK", "CHECK")

# Paper-format
main_metrics <- c("Accuracy","Macro_F1","ORC","GC","ADC","Macro_MAE")
fmt_ci <- function(est,lo,up) if (is.na(est)) NA_character_ else if (is.na(lo)||is.na(up)) sprintf("%.3f [NA]",est) else sprintf("%.3f [%.3f, %.3f]",est,lo,up)
gm <- bca_gen[bca_gen$Metric %in% main_metrics, ]
gm$Estimate_CI <- mapply(fmt_ci, gm$Original, gm$BCa_Lower, gm$BCa_Upper)
gen_main_wide <- tidyr::pivot_wider(gm[,c("Source","Country","Model","Metric","Estimate_CI")],
                                    names_from=Metric, values_from=Estimate_CI)
gen_main_wide <- gen_main_wide[, c("Source","Country","Model", main_metrics)]
flagged <- bca_gen[bca_gen$Status=="CHECK", c("Source","Country","Model","Metric","Original","BCa_Lower","BCa_Upper","z0","a","Health_Flags")]

out_path <- file.path(OUTPUT_DIR, "Pool_to_country_BCa.xlsx")
writexl::write_xlsx(list(Gen_All=bca_gen, Gen_Main=gen_main_wide, Health_Check_FLAGS=flagged), path=out_path)

cat("\n==================== DONE ====================\n")
cat("Saved:", out_path, "\n")
cat("  Gen_All           -", nrow(bca_gen), "rows\n")
cat("  Gen_Main          -", nrow(gen_main_wide), "rows (paper format)\n")
cat("  Health_Check_FLAGS-", nrow(flagged), "rows flagged\n")
cat("\n>>> FIRST verify the self-check above: CHARLS test n = 424 ?\n")
cat(">>> If yes, the test sets are aligned with the cohort-specific analysis.\n")