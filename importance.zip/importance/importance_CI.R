# Bootstrap CI for permutation variable importance, HPC array job
# Each task runs one bootstrap replicate for all models
# Usage: Rscript 06_bootstrap_importance.R ${SLURM_ARRAY_TASK_ID}
# Submit: sbatch --array=1-1000 jobs/run_bootstrap_importance.sh

source("config.R")
source("functions.R")

args <- commandArgs(trailingOnly = TRUE)
b    <- as.integer(args[1])

cat("Running bootstrap importance, replicate:", b, "\n")


# 1. Load tuning results from tuning.R

tuning_results <- readRDS(file.path(output_dir, "tuning_collect_results.rds"))

best_logit_formula  <- tuning_results$best_logit_formula
best_of_nsets       <- tuning_results$best_of_nsets
best_of_ntreeperdiv <- tuning_results$best_of_ntreeperdiv
best_of_ntreefinal  <- tuning_results$best_of_ntreefinal
best_of_mtry        <- tuning_results$best_of_mtry
best_svm_cost       <- tuning_results$best_svm_cost
best_svm_sigma      <- tuning_results$best_svm_sigma
best_knn_kmax       <- tuning_results$best_knn_kmax
best_knn_distance   <- tuning_results$best_knn_distance
best_knn_kernel     <- tuning_results$best_knn_kernel

# Helper functions

make_stratified_boot_index <- function(y, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  y            <- factor(y, levels = levels(y), ordered = TRUE)
  idx_by_class <- split(seq_along(y), y)
  idx_boot     <- unlist(
    lapply(idx_by_class, function(idx) {
      sample(idx, size = length(idx), replace = TRUE)
    }),
    use.names = FALSE
  )
  idx_boot
}

extract_svm_score <- function(raw_pred) {
  raw_df <- as.data.frame(raw_pred)
  if (".pred" %in% names(raw_df)) return(as.numeric(raw_df$.pred))
  numeric_cols <- names(raw_df)[sapply(raw_df, is.numeric)]
  if (length(numeric_cols) == 0) {
    stop("No numeric raw-score column found in SVM prediction output.")
  }
  as.numeric(raw_df[[numeric_cols[1]]])
}

calc_orc_from_score <- function(y_true, score_vec) {
  y_true_num <- as.numeric(y_true)
  score_vec  <- as.numeric(score_vec)
  
  if (length(y_true_num) != length(score_vec)) {
    stop("y_true and score_vec must have the same length.")
  }
  if (all(is.na(score_vec))) return(NA_real_)
  
  classes  <- sort(unique(y_true_num[!is.na(y_true_num)]))
  auc_list <- c()
  
  if (length(classes) < 2) return(NA_real_)
  
  for (i in 1:(length(classes) - 1)) {
    for (j in (i + 1):length(classes)) {
      low   <- classes[i]
      high  <- classes[j]
      idx   <- which(y_true_num %in% c(low, high))
      y_bin <- ifelse(y_true_num[idx] == high, 1, 0)
      score <- score_vec[idx]
      keep  <- !is.na(score)
      y_bin <- y_bin[keep]
      score <- score[keep]
      
      if (length(unique(y_bin)) == 2 && length(unique(score)) > 1) {
        auc_list <- c(
          auc_list,
          as.numeric(pROC::auc(response = y_bin, predictor = score, quiet = TRUE))
        )
      }
    }
  }
  
  if (length(auc_list) == 0) return(NA_real_)
  mean(auc_list, na.rm = TRUE)
}

predict_score_for_importance <- function(model, new_data, y_true, model_type) {
  y_true <- factor(y_true, levels = levels(y_true), ordered = TRUE)
  
  if (model_type == "logit") {
    prob  <- predict(model, newdata = new_data, type = "probs")
    prob  <- align_prob_matrix(prob, levels(y_true))
    score <- as.numeric(prob %*% seq_along(levels(y_true)))
    
  } else if (model_type == "forest") {
    pred  <- predict(model, newdata = new_data)
    prob  <- align_prob_matrix(pred$classprobs, levels(y_true))
    score <- as.numeric(prob %*% seq_along(levels(y_true)))
    
  } else if (model_type == "svm") {
    raw_pred <- predict(model, new_data = new_data, type = "raw")
    score    <- extract_svm_score(raw_pred)
    
  } else if (model_type == "knn") {
    prob  <- predict(model, newdata = new_data, type = "prob")
    prob  <- align_prob_matrix(prob, levels(y_true))
    score <- as.numeric(prob %*% seq_along(levels(y_true)))
    
  } else {
    stop("model_type must be logit, forest, svm, or knn.")
  }
  
  as.numeric(score)
}

permutation_importance_orc <- function(model, model_name, model_type,
                                       test_data, y_true, predictor_cols,
                                       n_repeats = 5, seed = 123) {
  set.seed(seed)
  y_true <- factor(y_true, levels = levels(y_true), ordered = TRUE)
  
  base_score <- predict_score_for_importance(
    model      = model,
    new_data   = test_data,
    y_true     = y_true,
    model_type = model_type
  )
  base_orc <- calc_orc_from_score(y_true, base_score)
  
  out_list <- lapply(predictor_cols, function(vv) {
    perm_values <- c()
    
    for (rr in seq_len(n_repeats)) {
      perm_data       <- test_data
      perm_data[[vv]] <- sample(perm_data[[vv]])
      
      perm_score <- predict_score_for_importance(
        model      = model,
        new_data   = perm_data,
        y_true     = y_true,
        model_type = model_type
      )
      perm_orc    <- calc_orc_from_score(y_true, perm_score)
      perm_values <- c(perm_values, perm_orc)
    }
    
    data.frame(
      Country          = country_label,
      Model            = model_name,
      Predictor        = vv,
      Index            = "Importance",
      Base_ORC         = base_orc,
      Permuted_ORC_Mean = mean(perm_values, na.rm = TRUE),
      Permuted_ORC_SD  = sd(perm_values, na.rm = TRUE),
      Importance       = base_orc - mean(perm_values, na.rm = TRUE),
      N_Repeats        = n_repeats,
      Bootstrap_ID     = b
    )
  })
  
  bind_rows(out_list)
}

# Fit all models on train+valid, evaluate on test

cat("Fitting models on train+valid...\n")

scaled_dat  <- make_scaled_train_test(train_plus_valid, test_ord)
train_final <- scaled_dat$train_final
test_final  <- scaled_dat$test_final

y_test         <- factor(test_final$burden_score_ord,
                         levels = levels(train_final$burden_score_ord),
                         ordered = TRUE)
outcome_levels <- levels(train_final$burden_score_ord)
predictor_cols <- setdiff(names(test_final), "burden_score_ord")

# Fit each model once on original train_final
model_logit  <- MASS::polr(formula = best_logit_formula, data = train_final, Hess = TRUE)

model_forest <- ordinalForest::ordfor(
  depvar       = "burden_score_ord",
  data         = train_final,
  nsets        = best_of_nsets,
  ntreeperdiv  = best_of_ntreeperdiv,
  ntreefinal   = best_of_ntreefinal,
  mtry         = best_of_mtry,
  perffunction = "probability"
)

model_svm <- mildsvm::svor_exc(
  burden_score_ord ~ .,
  data    = train_final,
  cost    = best_svm_cost,
  control = list(
    kernel    = "radial",
    sigma     = best_svm_sigma,
    scale     = FALSE,
    max_steps = 5000
  )
)

model_knn <- kknn::train.kknn(
  burden_score_ord ~ .,
  data     = train_final,
  kmax     = best_knn_kmax,
  distance = best_knn_distance,
  kernel   = best_knn_kernel,
  scale    = FALSE
)

cat("All models fitted. Running bootstrap importance replicate", b, "...\n")

# Generate one bootstrap sample and compute importance

idx_b  <- make_stratified_boot_index(y_test, seed = 123 + b)
y_b    <- factor(y_test[idx_b], levels = levels(y_test), ordered = TRUE)

test_final_b <- test_final[idx_b, , drop = FALSE]

# SVM needs data without outcome column
test_final_b_no_y <- test_final_b %>% dplyr::select(-burden_score_ord)

boot_importance_list <- list()

# Logit importance
boot_importance_list[["logit"]] <- tryCatch({
  permutation_importance_orc(
    model          = model_logit,
    model_name     = "Ordinal Logistic Regression",
    model_type     = "logit",
    test_data      = test_final_b,
    y_true         = y_b,
    predictor_cols = predictor_cols,
    n_repeats      = importance_n_repeats,
    seed           = 123 + b
  )
}, error = function(e) {
  message("Logit importance error, b=", b, ": ", e$message)
  NULL
})

# Forest importance
boot_importance_list[["forest"]] <- tryCatch({
  permutation_importance_orc(
    model          = model_forest,
    model_name     = "Ordinal Forest",
    model_type     = "forest",
    test_data      = test_final_b,
    y_true         = y_b,
    predictor_cols = predictor_cols,
    n_repeats      = importance_n_repeats,
    seed           = 123 + b
  )
}, error = function(e) {
  message("Forest importance error, b=", b, ": ", e$message)
  NULL
})

# SVM importance
boot_importance_list[["svm"]] <- tryCatch({
  permutation_importance_orc(
    model          = model_svm,
    model_name     = "Ordinal SVM",
    model_type     = "svm",
    test_data      = test_final_b_no_y,
    y_true         = y_b,
    predictor_cols = predictor_cols,
    n_repeats      = importance_n_repeats,
    seed           = 123 + b
  )
}, error = function(e) {
  message("SVM importance error, b=", b, ": ", e$message)
  NULL
})

# KNN importance
boot_importance_list[["knn"]] <- tryCatch({
  permutation_importance_orc(
    model          = model_knn,
    model_name     = "Ordinal KNN",
    model_type     = "knn",
    test_data      = test_final_b,
    y_true         = y_b,
    predictor_cols = predictor_cols,
    n_repeats      = importance_n_repeats,
    seed           = 123 + b
  )
}, error = function(e) {
  message("KNN importance error, b=", b, ": ", e$message)
  NULL
})

boot_importance <- bind_rows(boot_importance_list)

# 5. Save this replicate's results

importance_dir <- file.path(output_dir, "bootstrap_importance")
if (!dir.exists(importance_dir)) dir.create(importance_dir, recursive = TRUE)

save_path <- file.path(importance_dir, paste0("importance_", b, ".rds"))
saveRDS(boot_importance, save_path)

cat("Bootstrap importance replicate", b, "saved to:", save_path, "\n")