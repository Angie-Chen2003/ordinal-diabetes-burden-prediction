
# ============================================================
# config.R
# Change only this file when switching to a different dataset.
# All other scripts remain unchanged.
# ============================================================

country_label  <- "PLACEHOLDER"
data_path      <- "/path/to/Dataset/PLACEHOLDER_final.xlsx"
output_dir     <- "/path/to/Output/PLACEHOLDER"
cols_to_remove <- c("social_eco_ppp", "country")

B_metric             <- 1000
B_importance         <- 1000
importance_n_repeats <- 5