# ============================================================
# 14_hpc_bca_importance.R  -- HPC BCa for permutation importance, all 10 datasets
# ------------------------------------------------------------
# Upgrades permutation-importance CIs from percentile to BCa, for ALL 10 datasets
# x 4 R models x each model's predictors. Runs on HPC (single job + mclapply),
# because importance jackknife is heavy: each leave-one-out recomputes
# base_orc + (n_predictors x 5 permuted_orc).
#
# Method (decided: path A -- statistically correct BCa):
#   theta_hat (point estimate) = importance on the ORIGINAL full test set
#     (NOT the bootstrap mean; bootstrap mean is biased and would void z0).
#   bootstrap distribution = read existing Output/<ds>/bootstrap_importance/*.rds
#     (1000 reps, from 06; NO rerun).
#   jackknife = NEW; leave-one-out on test, FIXED permutation seed (123) so
#     jackknife variation is only from the dropped sample, not reshuffling.
#   Importance = base_orc - mean(permuted_orc over 5 repeats), per (model,predictor),
#     faithful to 06's permutation_importance_orc.
#   forest/svm seeded (FIT_SEED=2026); kknn cumulative prob kept as-is.
#
# Submit: sbatch run_hpc_bca_importance.sh
# ============================================================

suppressMessages({
  library(parallel); library(readxl); library(dplyr); library(caret); library(pROC)
  library(MASS); library(ordinalForest); library(mildsvm); library(kknn); library(writexl)
})

HPC_CODE    <- "/scratch/xw3922/HPC_code"
RSCRIPT_DIR <- file.path(HPC_CODE, "R_script")
DATASET_DIR <- file.path(HPC_CODE, "Dataset")
OUTPUT_DIR  <- file.path(HPC_CODE, "Output")

FIT_SEED  <- 2026
PERM_SEED <- 123   # original & jackknife permutation seed (06's b analogue)
N_REPEATS <- 5
B_BOOT    <- 1000

N_CORES <- as.integer(Sys.getenv("SLURM_CPUS_PER_TASK", unset = "8"))
if (is.na(N_CORES) || N_CORES < 1) N_CORES <- 8
cat("Using", N_CORES, "cores.\n")

# 10 datasets with per-dataset cols_to_remove (confirmed earlier)
datasets <- list(
  list(label="CHARLS",            file="CHARLS_final.xlsx",                           cols=c("social_eco_ppp","country")),
  list(label="HRS",               file="HRS_final.xlsx",                              cols=c("social_eco_ppp","country")),
  list(label="KLoSA",             file="KLoSA_final.xlsx",                            cols=c("social_eco_ppp","country","medical_insurance")),
  list(label="LASI",              file="LASI_final.xlsx",                             cols=c("social_eco_ppp","country")),
  list(label="MAHS",              file="MAHS_final.xlsx",                             cols=c("social_eco_ppp","country")),
  list(label="SA",                file="SA_final.xlsx",                               cols=c("social_eco_ppp","country")),
  list(label="SHARE",             file="SHARE_final.xlsx",                            cols=c("social_eco_ppp","country")),
  list(label="UK",                file="UK_final.xlsx",                               cols=c("social_eco_ppp","country","medical_insurance")),
  list(label="Pool",              file="Pool_dataset.xlsx",                           cols=character(0)),
  list(label="Balanced_Pool_200", file="Balanced_Pool_dataset_200_per_country.xlsx",  cols=character(0))
)

setwd(RSCRIPT_DIR)

# ============================================================
# ORC-from-score (identical to 06)
# ============================================================
extract_svm_score <- function(raw_pred) {
  raw_df <- as.data.frame(raw_pred)
  if (".pred" %in% names(raw_df)) return(as.numeric(raw_df$.pred))
  nc <- names(raw_df)[sapply(raw_df, is.numeric)]; if (length(nc)==0) stop("no numeric score")
  as.numeric(raw_df[[nc[1]]])
}
calc_orc_from_score <- function(y_true, score_vec) {
  y <- as.numeric(y_true); s <- as.numeric(score_vec)
  if (all(is.na(s))) return(NA_real_)
  cls <- sort(unique(y[!is.na(y)])); if (length(cls)<2) return(NA_real_)
  au <- c()
  for (i in 1:(length(cls)-1)) for (j in (i+1):length(cls)) {
    idx <- which(y %in% c(cls[i], cls[j])); yb <- ifelse(y[idx]==cls[j],1,0); sv <- s[idx]
    keep <- !is.na(sv); yb <- yb[keep]; sv <- sv[keep]
    if (length(unique(yb))==2 && length(unique(sv))>1)
      au <- c(au, as.numeric(pROC::auc(response=yb, predictor=sv, quiet=TRUE)))
  }
  if (length(au)==0) NA_real_ else mean(au, na.rm=TRUE)
}
predict_score_for_importance <- function(model, new_data, y_true, model_type) {
  yl <- levels(y_true)
  if (model_type=="logit") { pr <- align_prob_matrix(predict(model,newdata=new_data,type="probs"),yl); as.numeric(pr %*% seq_along(yl)) }
  else if (model_type=="forest") { pd <- predict(model,newdata=new_data); pr <- align_prob_matrix(pd$classprobs,yl); as.numeric(pr %*% seq_along(yl)) }
  else if (model_type=="svm") { extract_svm_score(predict(model,new_data=new_data,type="raw")) }
  else if (model_type=="knn") { pr <- align_prob_matrix(predict(model,newdata=new_data,type="prob"),yl); as.numeric(pr %*% seq_along(yl)) }
  else stop("bad model_type")
}
# Importance per predictor (deterministic via perm_seed)
importance_vec <- function(model, model_type, test_data, y_true, predictor_cols,
                           n_repeats=N_REPEATS, perm_seed=PERM_SEED) {
  set.seed(perm_seed)
  y_true <- factor(y_true, levels=levels(y_true), ordered=TRUE)
  base_orc <- calc_orc_from_score(y_true, predict_score_for_importance(model, test_data, y_true, model_type))
  imp <- sapply(predictor_cols, function(vv) {
    pv <- numeric(n_repeats)
    for (rr in seq_len(n_repeats)) {
      pd <- test_data; pd[[vv]] <- sample(pd[[vv]])
      pv[rr] <- calc_orc_from_score(y_true, predict_score_for_importance(model, pd, y_true, model_type))
    }
    base_orc - mean(pv, na.rm=TRUE)
  })
  setNames(as.numeric(imp), predictor_cols)
}

compute_bca <- function(boot_vals, theta_hat, jack_vals, alpha=0.05) {
  boot_vals <- boot_vals[!is.na(boot_vals)]; B <- length(boot_vals)
  if (B<10 || is.na(theta_hat)) return(list(lower=NA,upper=NA,z0=NA,a=NA,note="insufficient"))
  pl <- mean(boot_vals < theta_hat); if (pl<=0) pl <- 1/(2*B); if (pl>=1) pl <- 1-1/(2*B)
  z0 <- qnorm(pl); jv <- jack_vals[!is.na(jack_vals)]
  if (length(jv)<3) { a <- 0; note <- "insufficient jackknife" }
  else { jm <- mean(jv); df <- jm-jv; den <- 6*(sum(df^2))^1.5; a <- if (den==0) 0 else sum(df^3)/den; note <- "" }
  zl <- qnorm(alpha/2); zh <- qnorm(1-alpha/2); adj <- function(zb) pnorm(z0+(z0+zb)/(1-a*(z0+zb)))
  list(lower=as.numeric(quantile(boot_vals,adj(zl),na.rm=TRUE,names=FALSE)),
       upper=as.numeric(quantile(boot_vals,adj(zh),na.rm=TRUE,names=FALSE)), z0=z0, a=a, note=note)
}

# ============================================================
# Process one dataset
# ============================================================
process_dataset <- function(ds) {
  cat("\n########## DATASET:", ds$label, "(", format(Sys.time()), ") ##########\n")
  country_label  <<- ds$label
  data_path      <<- file.path(DATASET_DIR, ds$file)
  output_dir     <<- file.path(OUTPUT_DIR, ds$label)
  cols_to_remove <<- ds$cols
  source(file.path(RSCRIPT_DIR, "00_functions_data.r"))
  
  tr <- readRDS(file.path(output_dir, "tuning_collect_results.rds"))
  blf<-tr$best_logit_formula; ofn<-tr$best_of_nsets; ofp<-tr$best_of_ntreeperdiv
  oft<-tr$best_of_ntreefinal; ofm<-tr$best_of_mtry; sc<-tr$best_svm_cost; ss<-tr$best_svm_sigma
  kk<-tr$best_knn_kmax; kd<-tr$best_knn_distance; kn<-tr$best_knn_kernel
  
  scaled <- make_scaled_train_test(train_plus_valid, test_ord)
  train_final <- scaled$train_final; test_final <- scaled$test_final
  y_test <- factor(test_final$burden_score_ord, levels=levels(train_final$burden_score_ord), ordered=TRUE)
  predictor_cols <- setdiff(names(test_final), "burden_score_ord")
  cat("  predictors (", length(predictor_cols), "):", paste(predictor_cols, collapse=", "), "\n")
  
  model_logit  <- MASS::polr(formula=blf, data=train_final, Hess=TRUE)
  set.seed(FIT_SEED)
  model_forest <- ordinalForest::ordfor(depvar="burden_score_ord", data=train_final,
                                        nsets=ofn, ntreeperdiv=ofp, ntreefinal=oft, mtry=ofm, perffunction="probability")
  set.seed(FIT_SEED)
  model_svm <- mildsvm::svor_exc(burden_score_ord ~ ., data=train_final, cost=sc,
                                 control=list(kernel="radial", sigma=ss, scale=FALSE, max_steps=5000))
  model_knn <- kknn::train.kknn(burden_score_ord ~ ., data=train_final,
                                kmax=kk, distance=kd, kernel=kn, scale=FALSE)
  
  test_no_y <- test_final %>% dplyr::select(-burden_score_ord)
  models <- list(
    list(name="Ordinal Logistic Regression", m=model_logit,  type="logit",  td=test_final),
    list(name="Ordinal Forest",              m=model_forest, type="forest", td=test_final),
    list(name="Ordinal SVM",                 m=model_svm,    type="svm",    td=test_no_y),
    list(name="Ordinal KNN",                 m=model_knn,    type="knn",    td=test_final)
  )
  
  # ORIGINAL (path A: original full-test importance) ----
  cat("  original importance... (", format(Sys.time()), ")\n")
  orig_imp <- list()
  for (spec in models) {
    iv <- importance_vec(spec$m, spec$type, spec$td, y_test, predictor_cols)
    for (vv in predictor_cols)
      orig_imp[[length(orig_imp)+1]] <- data.frame(Model=spec$name, Predictor=vv,
                                                   Importance_Original=iv[[vv]], stringsAsFactors=FALSE)
  }
  orig_imp_df <- do.call(rbind, orig_imp)
  
  # BOOTSTRAP from disk ----
  imp_dir <- file.path(output_dir, "bootstrap_importance")
  files <- file.path(imp_dir, paste0("importance_", seq_len(B_BOOT), ".rds"))
  files <- files[file.exists(files)]
  boot_all <- bind_rows(lapply(files, readRDS))
  cat("  read", length(files), "bootstrap importance files.\n")
  
  # JACKKNIFE (parallel over leave-one-out) ----
  cat("  jackknife (parallel,", N_CORES, "cores)... (", format(Sys.time()), ")\n")
  n <- length(y_test)
  jack_store <- list()
  for (spec in models) {
    td_full <- spec$td
    rows <- mclapply(seq_len(n), function(i) {
      keep <- setdiff(seq_len(n), i)
      importance_vec(spec$m, spec$type, td_full[keep,,drop=FALSE],
                     factor(y_test[keep], levels=levels(y_test), ordered=TRUE), predictor_cols)
    }, mc.cores=N_CORES, mc.preschedule=TRUE)
    jmat <- do.call(rbind, rows); colnames(jmat) <- predictor_cols
    jack_store[[spec$name]] <- jmat
    cat("    ", spec$name, "jackknife done. (", format(Sys.time()), ")\n")
  }
  
  # BCa ----
  cat("  assembling BCa...\n")
  rows <- list()
  for (spec in models) {
    jmat <- jack_store[[spec$name]]
    for (vv in predictor_cols) {
      bv <- boot_all$Importance[boot_all$Model==spec$name & boot_all$Predictor==vv]
      th <- orig_imp_df$Importance_Original[orig_imp_df$Model==spec$name & orig_imp_df$Predictor==vv]
      res <- compute_bca(bv, th, jmat[, vv])
      rows[[length(rows)+1]] <- data.frame(Country=ds$label, Model=spec$name, Predictor=vv,
                                           Importance=round(th,4), BCa_Lower=round(res$lower,4), BCa_Upper=round(res$upper,4),
                                           z0=round(res$z0,4), a=round(res$a,4), Note=res$note, stringsAsFactors=FALSE)
    }
  }
  bca_imp <- do.call(rbind, rows)
  saveRDS(list(bca_imp=bca_imp, orig=orig_imp_df, jack=jack_store),
          file.path(output_dir, paste0(ds$label, "_importance_BCa.rds")))
  cat("  saved:", file.path(output_dir, paste0(ds$label, "_importance_BCa.rds")), "\n")
  bca_imp
}

# ============================================================
# Run all 10
# ============================================================
cat("HPC BCa importance, all 10 datasets. Start:", format(Sys.time()), "\n")
all_imp <- list()
for (ds in datasets) {
  res <- tryCatch(process_dataset(ds),
                  error=function(e){message(">>> ",ds$label," ERROR: ",e$message);NULL})
  if (!is.null(res)) all_imp[[ds$label]] <- res
}
bca_imp_all <- bind_rows(all_imp)

# Health check
flag_row <- function(imp, lo, up, z0, a) {
  f <- c()
  if (is.na(lo)||is.na(up)) f <- c(f,"NA_CI")
  if (!is.na(lo)&&!is.na(up)) { if (lo>up) f <- c(f,"REVERSED"); if (lo==up) f <- c(f,"COLLAPSED")
  if (!is.na(imp)&&(imp<min(lo,up)-1e-9||imp>max(lo,up)+1e-9)) f <- c(f,"EXCLUDES_PE") }
  if (!is.na(z0)&&abs(z0)>2) f <- c(f,"EXTREME_Z0"); if (!is.na(a)&&abs(a)>0.5) f <- c(f,"EXTREME_A")
  paste(f, collapse=", ")
}
bca_imp_all$Health_Flags <- mapply(flag_row, bca_imp_all$Importance, bca_imp_all$BCa_Lower,
                                   bca_imp_all$BCa_Upper, bca_imp_all$z0, bca_imp_all$a, USE.NAMES=FALSE)
bca_imp_all$Status <- ifelse(bca_imp_all$Health_Flags=="", "OK", "CHECK")

# paper format
fmt_ci <- function(e,l,u) if (is.na(e)) NA_character_ else if (is.na(l)||is.na(u)) sprintf("%.4f [NA]",e) else sprintf("%.4f [%.4f, %.4f]",e,l,u)
bca_imp_all$Importance_CI <- mapply(fmt_ci, bca_imp_all$Importance, bca_imp_all$BCa_Lower, bca_imp_all$BCa_Upper)
flagged <- bca_imp_all[bca_imp_all$Status=="CHECK", ]

out_path <- file.path(OUTPUT_DIR, "ALL_importance_BCa.xlsx")
writexl::write_xlsx(list(Importance_BCa_All=bca_imp_all, Health_Check_FLAGS=flagged), path=out_path)

cat("\n==================== DONE ====================\n")
cat("Saved:", out_path, "\n")
cat("  Importance_BCa_All -", nrow(bca_imp_all), "rows\n")
cat("  Health_Check_FLAGS -", nrow(flagged), "rows flagged\n")
cat("Finished:", format(Sys.time()), "\n")