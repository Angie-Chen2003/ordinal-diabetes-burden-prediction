# ============================================================
# 09_bca_all_datasets.R  -- automated BCa over all 10 datasets
# ------------------------------------------------------------
# Runs the deterministic, same-source BCa pipeline (verified on CHARLS in
# 09_bca_ci_full.R) automatically across all 10 datasets in one go.
#
# For each dataset it:
#   - sets country_label / data_path / output_dir / cols_to_remove
#     (replacing config.R; config.R is NOT read here)
#   - source()s 00_functions_data.R to build the SAME splits as the original
#     pipeline (faithful reproduction; 00 is reused unchanged)
#   - rebuilds fixed predictions with deterministic fits (set.seed before
#     forest/svm) -> original point estimates
#   - prediction-level jackknife -> acceleration a
#   - same-source prediction-level bootstrap (replicates 05: stratified,
#     fixed-margin, seed = BOOT_SEED_BASE + b) -> bias z0
#   - assembles BCa CIs for all 4 R models x 3 datasets (Train/Validation/Test)
#   - auto-verifies rebuilt original vs each dataset's Excel (forest excepted)
#   - saves per-dataset RDS + a combined Excel into Output_new/
#
# Scope: 4 R models only (logit/forest/svm/knn). CORAL and Ordinal XGBoost are
#        a separate Python implementation and are out of scope here.
#        pool-to-country (script 08) reports point estimates only -> out of scope.
#
# kknn note: kknn outputs CUMULATIVE probabilities for ordinal outcomes. We keep
#        this as-is (faithful reproduction). Whether cumulative vs class prob is
#        appropriate for ORC/GC/ADC is a statistical-definition question for the
#        methods lead, NOT changed here.
#
# Usage: setwd("~/Documents/Jeannette/HPC_code/R_script"); source("09_bca_all_datasets.r")
#        (config.R and 00_functions_data.R must be in that directory.)
# ============================================================

# ------------------------------------------------------------
# Paths and constants
# ------------------------------------------------------------
HPC_ROOT       <- "~/Documents/Jeannette/HPC_code"
DATASET_DIR    <- file.path(HPC_ROOT, "Dataset")
OUTPUT_DIR_OLD <- file.path(HPC_ROOT, "Output")       # read: tuning + old bootstrap + Excel
OUTPUT_DIR_NEW <- file.path(HPC_ROOT, "Output_new")   # write: all BCa outputs

FIT_SEED       <- 2026   # fixed seed before each random fit (forest, svm)
BOOT_SEED_BASE <- 123    # bootstrap seed = BOOT_SEED_BASE + b (replicates 05)
B_BOOT         <- 1000   # bootstrap replicates (match 05)

metric_names <- c("Accuracy", "Macro_F1", "MAE", "MSE", "MZOE",
                  "Macro_MAE", "ORC", "GC", "ADC")

# ------------------------------------------------------------
# The 10 datasets, with per-dataset cols_to_remove (confirmed by reverse-
# engineering each dataset's importance table -- NOT guessed):
#   - 6 single countries: drop social_eco_ppp + country (keep social_eco, insurance)
#   - UK, KLoSA:          additionally drop medical_insurance (no within-country
#                         variation; removed per Methods)
#   - Pool/Balanced:      cols_to_remove EMPTY. social_eco_ppp is kept (only SES
#                         var); country must NOT be dropped so 00's else-branch can
#                         rename country -> country_factor (Balanced uses 'country',
#                         Pool already has 'country_factor'). burden_score /
#                         burden_score_int are excluded automatically via outcome_cols.
# ------------------------------------------------------------
datasets <- list(
  list(label = "CHARLS",            file = "CHARLS_final.xlsx",                          cols = c("social_eco_ppp", "country")),
  list(label = "HRS",               file = "HRS_final.xlsx",                             cols = c("social_eco_ppp", "country")),
  list(label = "KLoSA",             file = "KLoSA_final.xlsx",                           cols = c("social_eco_ppp", "country", "medical_insurance")),
  list(label = "LASI",              file = "LASI_final.xlsx",                            cols = c("social_eco_ppp", "country")),
  list(label = "MAHS",              file = "MAHS_final.xlsx",                            cols = c("social_eco_ppp", "country")),
  list(label = "SA",                file = "SA_final.xlsx",                              cols = c("social_eco_ppp", "country")),
  list(label = "SHARE",             file = "SHARE_final.xlsx",                           cols = c("social_eco_ppp", "country")),
  list(label = "UK",                file = "UK_final.xlsx",                              cols = c("social_eco_ppp", "country", "medical_insurance")),
  list(label = "Pool",              file = "Pool_dataset.xlsx",                          cols = character(0)),
  list(label = "Balanced_Pool_200", file = "Balanced_Pool_dataset_200_per_country.xlsx", cols = character(0))
)

# ============================================================
# Helpers that do NOT depend on dataset globals
# ============================================================

extract_svm_score <- function(raw_pred) {
  raw_df <- as.data.frame(raw_pred)
  if (".pred" %in% names(raw_df)) return(as.numeric(raw_df$.pred))
  numeric_cols <- names(raw_df)[sapply(raw_df, is.numeric)]
  if (length(numeric_cols) == 0) stop("No numeric raw-score column found in SVM output.")
  as.numeric(raw_df[[numeric_cols[1]]])
}

make_stratified_boot_index <- function(y, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  y            <- factor(y, levels = levels(y), ordered = TRUE)
  idx_by_class <- split(seq_along(y), y)
  unlist(lapply(idx_by_class, function(idx) sample(idx, size = length(idx), replace = TRUE)),
         use.names = FALSE)
}

compute_bca <- function(boot_vals, theta_hat, jack_vals, alpha = 0.05) {
  boot_vals <- boot_vals[!is.na(boot_vals)]
  B <- length(boot_vals)
  if (B < 10 || is.na(theta_hat)) return(list(lower = NA, upper = NA, z0 = NA, a = NA, note = "insufficient data"))
  prop_less <- mean(boot_vals < theta_hat)
  if (prop_less <= 0) prop_less <- 1 / (2 * B)
  if (prop_less >= 1) prop_less <- 1 - 1 / (2 * B)
  z0 <- qnorm(prop_less)
  jv <- jack_vals[!is.na(jack_vals)]
  if (length(jv) < 3) { a <- 0; note <- "insufficient jackknife, a=0 (BC fallback)" }
  else {
    jm <- mean(jv); diffs <- jm - jv
    den <- 6 * (sum(diffs^2))^(1.5)
    a   <- if (den == 0) 0 else sum(diffs^3) / den
    note <- ""
  }
  z_lo <- qnorm(alpha/2); z_hi <- qnorm(1 - alpha/2)
  adj  <- function(zb) pnorm(z0 + (z0 + zb) / (1 - a * (z0 + zb)))
  a1 <- adj(z_lo); a2 <- adj(z_hi)
  list(lower = as.numeric(quantile(boot_vals, a1, na.rm = TRUE, names = FALSE)),
       upper = as.numeric(quantile(boot_vals, a2, na.rm = TRUE, names = FALSE)),
       z0 = z0, a = a, note = note)
}

# ============================================================
# Core: process ONE dataset, return its BCa table + verification log
# ============================================================

process_one_dataset <- function(ds) {
  label <- ds$label
  cat("\n\n##############################################################\n")
  cat("#  DATASET:", label, "\n")
  cat("##############################################################\n")
  
  # --- set the four config variables, then source 00 (faithful reproduction) ---
  country_label  <<- label
  data_path      <<- file.path(DATASET_DIR, ds$file)
  output_dir     <<- file.path(OUTPUT_DIR_OLD, label)
  cols_to_remove <<- ds$cols
  
  if (!file.exists(data_path)) { cat("  !!! data file missing:", data_path, "\n"); return(NULL) }
  source("00_functions_data.R")   # builds charls_model, train_ord, valid_ord, test_ord, train_plus_valid, helpers
  
  bca_out_dir <- file.path(OUTPUT_DIR_NEW, label)
  if (!dir.exists(bca_out_dir)) dir.create(bca_out_dir, recursive = TRUE)
  
  # --- load best tuned params for this dataset ---
  tr_path <- file.path(output_dir, "tuning_collect_results.rds")
  if (!file.exists(tr_path)) { cat("  !!! tuning_collect_results.rds missing for", label, "\n"); return(NULL) }
  tuning_results <- readRDS(tr_path)
  
  blf  <- tuning_results$best_logit_formula
  ofn  <- tuning_results$best_of_nsets;       ofp <- tuning_results$best_of_ntreeperdiv
  oft  <- tuning_results$best_of_ntreefinal;  ofm <- tuning_results$best_of_mtry
  sc   <- tuning_results$best_svm_cost;       ss  <- tuning_results$best_svm_sigma
  kk   <- tuning_results$best_knn_kmax;       kd  <- tuning_results$best_knn_distance
  kn   <- tuning_results$best_knn_kernel
  
  # --- fit/pred closures (capture this dataset's params) ---
  fit_logit  <- function(dat) MASS::polr(formula = blf, data = dat, Hess = TRUE)
  pred_logit <- function(model, newdat, ol) list(
    pred = predict(model, newdata = newdat, type = "class"),
    prob_mat = align_prob_matrix(predict(model, newdata = newdat, type = "probs"), ol))
  
  fit_forest <- function(dat) { set.seed(FIT_SEED)
    ordinalForest::ordfor(depvar = "burden_score_ord", data = dat,
                          nsets = ofn, ntreeperdiv = ofp, ntreefinal = oft, mtry = ofm, perffunction = "probability") }
  pred_forest <- function(model, newdat, ol) { p <- predict(model, newdata = newdat)
  list(pred = p$ypred, prob_mat = align_prob_matrix(p$classprobs, ol)) }
  
  fit_svm <- function(dat) { set.seed(FIT_SEED)
    mildsvm::svor_exc(burden_score_ord ~ ., data = dat, cost = sc,
                      control = list(kernel = "radial", sigma = ss, scale = FALSE, max_steps = 5000)) }
  pred_svm <- function(model, newdat, ol) {
    x_new <- newdat %>% dplyr::select(-burden_score_ord)
    list(pred = predict(model, new_data = x_new, type = "class")$.pred_class,
         score_vec = extract_svm_score(predict(model, new_data = x_new, type = "raw"))) }
  
  fit_knn <- function(dat) kknn::train.kknn(burden_score_ord ~ ., data = dat,
                                            kmax = kk, distance = kd, kernel = kn, scale = FALSE)
  pred_knn <- function(model, newdat, ol) list(   # keep kknn cumulative prob as-is
    pred = predict(model, newdata = newdat, type = "raw"),
    prob_mat = align_prob_matrix(predict(model, newdata = newdat, type = "prob"), ol))
  
  model_specs <- list(
    list(name = "Ordinal Logistic Regression", fit = fit_logit,  pred = pred_logit,  mt = "prob"),
    list(name = "Ordinal Forest",              fit = fit_forest, pred = pred_forest, mt = "prob"),
    list(name = "Ordinal SVM",                 fit = fit_svm,    pred = pred_svm,    mt = "score"),
    list(name = "Ordinal KNN",                 fit = fit_knn,    pred = pred_knn,    mt = "prob")
  )
  
  # --- per-dataset fit convention (same as 05) ---
  ds_defs <- list(
    Train      = list(train = "train_ord",        eval = "train_ord"),
    Validation = list(train = "train_ord",        eval = "valid_ord"),
    Test       = list(train = "train_plus_valid", eval = "test_ord")
  )
  
  build_fixed <- function(spec, train_data, eval_data) {
    scaled <- make_scaled_train_valid(train_data, eval_data)
    tf <- scaled$train_final; ef <- scaled$valid_final
    ol <- levels(tf$burden_score_ord)
    yv <- factor(ef$burden_score_ord, levels = ol, ordered = TRUE)
    model <- spec$fit(tf); po <- spec$pred(model, ef, ol)
    list(metric_type = spec$mt, outcome_levels = ol, y_true = yv,
         pred_class = factor(po$pred, levels = ol, ordered = TRUE),
         prob_mat = if (spec$mt == "prob") po$prob_mat else NULL,
         score_vec = if (spec$mt == "score") po$score_vec else NULL)
  }
  
  cat("  Building fixed predictions...\n")
  pred_store <- list()
  for (spec in model_specs) {
    pred_store[[spec$name]] <- list()
    for (dsn in names(ds_defs)) {
      tr <- get(ds_defs[[dsn]]$train, envir = globalenv())
      ev <- get(ds_defs[[dsn]]$eval,  envir = globalenv())
      res <- tryCatch(build_fixed(spec, tr, ev),
                      error = function(e) { message("    >>> ", spec$name, "/", dsn, " failed: ", e$message); NULL })
      if (!is.null(res)) pred_store[[spec$name]][[dsn]] <- res
    }
    if (length(pred_store[[spec$name]]) == 0) pred_store[[spec$name]] <- NULL
  }
  if (length(pred_store) == 0) { cat("  !!! all models failed for", label, "\n"); return(NULL) }
  
  metric_vec <- function(po, idx) {
    ol <- po$outcome_levels
    ys <- factor(po$y_true[idx], levels = ol, ordered = TRUE)
    ps <- factor(po$pred_class[idx], levels = ol, ordered = TRUE)
    cm <- tryCatch(caret::confusionMatrix(ps, ys), error = function(e) NULL)
    if (is.null(cm)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    if (po$metric_type == "prob")
      om <- tryCatch(calc_ordinal_metrics(ys, po$prob_mat[idx, , drop = FALSE]), error = function(e) NULL)
    else
      om <- tryCatch(calc_ordinal_metrics_from_score(ys, po$score_vec[idx]), error = function(e) NULL)
    if (is.null(om)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    ev <- eval_ordinal_model("tmp", ys, ps, cm, om)
    setNames(as.numeric(ev[1, metric_names]), metric_names)
  }
  
  # --- original ---
  cat("  Original point estimates...\n")
  orig_list <- list()
  for (m in names(pred_store)) for (dsn in names(pred_store[[m]])) {
    po <- pred_store[[m]][[dsn]]; v <- metric_vec(po, seq_along(po$y_true))
    orig_list[[length(orig_list)+1]] <- data.frame(Country=label, Model=m, Dataset=dsn,
                                                   as.list(v), check.names=FALSE, stringsAsFactors=FALSE)
  }
  original_df <- do.call(rbind, orig_list)
  
  # --- verify vs Excel (forest excepted) ---
  excel_path <- file.path(output_dir, paste0(label, "_all_final_tables.xlsx"))
  verify_log <- list()
  flagf <- function(model, mine, theirs) {
    if (is.na(mine)||is.na(theirs)) return("?")
    if (abs(mine-theirs) <= 0.001) return("OK")
    if (model == "Ordinal Forest") return("forest-expected")
    "MISMATCH"
  }
  if (file.exists(excel_path)) {
    ex_test <- tryCatch(readxl::read_xlsx(excel_path, sheet="Original_Test_No_CI"), error=function(e) NULL)
    ex_tv   <- tryCatch(readxl::read_xlsx(excel_path, sheet="Original_Train_Valid_No_CI"), error=function(e) NULL)
    n_mismatch <- 0
    for (i in seq_len(nrow(original_df))) {
      r <- original_df[i, ]; ds_label <- r$Dataset; m <- r$Model
      ex <- if (ds_label == "Test") ex_test else ex_tv
      if (is.null(ex)) next
      exrow <- if (ds_label == "Test") ex[ex$Model==m, ] else ex[ex$Model==m & ex$Dataset==ds_label, ]
      if (nrow(exrow) == 0) next
      for (mt in metric_names) {
        mine <- round(r[[mt]],3); theirs <- round(as.numeric(exrow[[mt]]),3)
        fl <- flagf(m, mine, theirs)
        if (fl == "MISMATCH") {
          n_mismatch <- n_mismatch + 1
          verify_log[[length(verify_log)+1]] <- sprintf("%s | %s | %s: rebuilt=%s excel=%s", ds_label, m, mt, mine, theirs)
        }
      }
    }
    cat("  Verification: ", n_mismatch, " non-forest MISMATCH(es)",
        if (n_mismatch>0) " <<< CHECK verify_log" else " (clean)", "\n", sep="")
  } else {
    cat("  Excel not found; skipping verification for", label, "\n")
  }
  
  # --- jackknife ---
  cat("  Jackknife...\n")
  jack_store <- list()
  for (m in names(pred_store)) { jack_store[[m]] <- list()
  for (dsn in names(pred_store[[m]])) {
    po <- pred_store[[m]][[dsn]]; n <- length(po$y_true)
    jm <- matrix(NA_real_, n, length(metric_names), dimnames=list(NULL, metric_names))
    for (i in seq_len(n)) jm[i, ] <- metric_vec(po, setdiff(seq_len(n), i))
    jack_store[[m]][[dsn]] <- jm
  }
  }
  
  # --- same-source bootstrap ---
  cat("  Same-source bootstrap (", B_BOOT, " reps)...\n", sep="")
  new_boot <- list()
  for (m in names(pred_store)) { new_boot[[m]] <- list()
  for (dsn in names(pred_store[[m]])) {
    po <- pred_store[[m]][[dsn]]
    bm <- matrix(NA_real_, B_BOOT, length(metric_names), dimnames=list(NULL, metric_names))
    for (b in seq_len(B_BOOT)) {
      idx <- make_stratified_boot_index(po$y_true, seed = BOOT_SEED_BASE + b)
      bm[b, ] <- metric_vec(po, idx)
    }
    new_boot[[m]][[dsn]] <- bm
  }
  }
  
  # --- BCa ---
  cat("  Assembling BCa...\n")
  rows <- list()
  for (m in names(pred_store)) for (dsn in names(pred_store[[m]])) {
    bmat <- new_boot[[m]][[dsn]]; jmat <- jack_store[[m]][[dsn]]
    orow <- original_df[original_df$Model==m & original_df$Dataset==dsn, ]
    for (mt in metric_names) {
      res <- compute_bca(bmat[, mt], orow[[mt]], jmat[, mt])
      rows[[length(rows)+1]] <- data.frame(
        Country=label, Model=m, Dataset=dsn, Metric=mt,
        Original=round(orow[[mt]],4), BCa_Lower=round(res$lower,4), BCa_Upper=round(res$upper,4),
        z0=round(res$z0,4), a=round(res$a,4), Note=res$note, stringsAsFactors=FALSE)
    }
  }
  bca_table <- do.call(rbind, rows)
  
  # --- save per-dataset ---
  saveRDS(list(bca_table=bca_table, original_df=original_df, new_boot=new_boot,
               jack_store=jack_store, verify_log=verify_log,
               seeds=list(FIT_SEED=FIT_SEED, BOOT_SEED_BASE=BOOT_SEED_BASE, B=B_BOOT)),
          file.path(bca_out_dir, paste0(label, "_BCa_full.rds")))
  cat("  Saved RDS for", label, "\n")
  
  list(bca_table = bca_table, verify_log = verify_log)
}

# ============================================================
# Run all datasets
# ============================================================

if (!dir.exists(OUTPUT_DIR_NEW)) dir.create(OUTPUT_DIR_NEW, recursive = TRUE)

all_bca   <- list()
all_verify <- list()
for (ds in datasets) {
  res <- tryCatch(process_one_dataset(ds),
                  error = function(e) { message(">>> DATASET ", ds$label, " ERROR: ", e$message); NULL })
  if (!is.null(res)) {
    all_bca[[ds$label]]    <- res$bca_table
    all_verify[[ds$label]] <- res$verify_log
  }
}

bca_all_combined <- do.call(rbind, all_bca)

# ============================================================
# Combined export
# ============================================================

cat("\n\n==================== SUMMARY ====================\n")
cat("Datasets processed:", length(all_bca), "of", length(datasets), "\n")
for (lab in names(all_verify)) {
  nm <- length(all_verify[[lab]])
  cat(sprintf("  %-18s %s\n", lab, if (nm==0) "verification clean (forest excepted)" else paste0(nm, " non-forest MISMATCH(es) <<< CHECK")))
}

# Test-only view (the main reported results)
bca_test_only <- bca_all_combined[bca_all_combined$Dataset == "Test", ]

writexl::write_xlsx(
  list(
    BCa_All        = bca_all_combined,
    BCa_Test_Only  = bca_test_only
  ),
  path = file.path(OUTPUT_DIR_NEW, "ALL_datasets_BCa.xlsx")
)
cat("\nCombined Excel saved to:", file.path(OUTPUT_DIR_NEW, "ALL_datasets_BCa.xlsx"), "\n")
cat("Per-dataset RDS saved under:", OUTPUT_DIR_NEW, "/<dataset>/\n", sep="")
cat("\nIf any dataset shows non-forest MISMATCH, inspect its verify_log in all_verify[['<dataset>']].\n")