# ============================================================
# 10_hpc_bca_pooled.R  -- HPC BCa for the two pooled datasets
# ------------------------------------------------------------
# Runs the deterministic, same-source BCa pipeline (verified locally on the
# 8 single-country datasets) for the two LARGE pooled datasets that are too big
# for local leave-one-out jackknife:
#     Pool  and  Balanced_Pool_200
#
# Single job + mclapply parallelism (consistent with 05_bootstrap_ci.R style).
# Submit with: sbatch run_hpc_bca_pooled.sh
#
# For each pooled dataset it:
#   - sets country_label / data_path / output_dir / cols_to_remove, then
#     source()s 00_functions_data.R  (faithful reproduction; 00 unchanged)
#   - rebuilds fixed predictions with deterministic fits (set.seed before
#     forest/svm) -> original point estimates
#   - prediction-level jackknife (parallelized with mclapply) -> acceleration a
#   - same-source prediction-level bootstrap (replicates 05: stratified,
#     fixed-margin, seed = BOOT_SEED_BASE + b) -> bias z0
#   - assembles BCa CIs for all 4 R models x 3 datasets (Train/Validation/Test)
#   - saves <label>_BCa_full.rds into that dataset's Output/<label>/ folder
#
# Scope: 4 R models (logit/forest/svm/knn). kknn cumulative prob kept as-is.
# ============================================================

suppressMessages({
  library(parallel)
})

# ------------------------------------------------------------
# Paths (HPC) and constants
# ------------------------------------------------------------
HPC_CODE   <- "/scratch/xw3922/HPC_code"
RSCRIPT_DIR<- file.path(HPC_CODE, "R_script")
DATASET_DIR<- file.path(HPC_CODE, "Dataset")
OUTPUT_DIR <- file.path(HPC_CODE, "Output")   # read inputs AND write outputs here

FIT_SEED       <- 2026
BOOT_SEED_BASE <- 123
B_BOOT         <- 1000

# Number of cores for mclapply. Reads SLURM_CPUS_PER_TASK if set, else 8.
N_CORES <- as.integer(Sys.getenv("SLURM_CPUS_PER_TASK", unset = "8"))
if (is.na(N_CORES) || N_CORES < 1) N_CORES <- 8
cat("Using", N_CORES, "cores for mclapply.\n")

metric_names <- c("Accuracy", "Macro_F1", "MAE", "MSE", "MZOE",
                  "Macro_MAE", "ORC", "GC", "ADC")

# The two pooled datasets. cols = character(0): keep social_eco_ppp; do NOT drop
# country (00's else-branch renames country -> country_factor for Balanced; Pool
# already has country_factor). burden_score/_int excluded via outcome_cols in 00.
pooled_datasets <- list(
  list(label = "Pool",              file = "Pool_dataset.xlsx",                          cols = character(0)),
  list(label = "Balanced_Pool_200", file = "Balanced_Pool_dataset_200_per_country.xlsx", cols = character(0))
)

# Make sure 00 is sourced from the right place regardless of getwd()
setwd(RSCRIPT_DIR)

# ============================================================
# Dataset-independent helpers
# ============================================================

extract_svm_score <- function(raw_pred) {
  raw_df <- as.data.frame(raw_pred)
  if (".pred" %in% names(raw_df)) return(as.numeric(raw_df$.pred))
  numeric_cols <- names(raw_df)[sapply(raw_df, is.numeric)]
  if (length(numeric_cols) == 0) stop("No numeric raw-score column found in SVM output.")
  as.numeric(raw_df[[numeric_cols[1]]])
}

make_stratified_boot_index <- function(y, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  y            <- factor(y, levels = levels(y), ordered = TRUE)
  idx_by_class <- split(seq_along(y), y)
  unlist(lapply(idx_by_class, function(idx) sample(idx, size = length(idx), replace = TRUE)),
         use.names = FALSE)
}

compute_bca <- function(boot_vals, theta_hat, jack_vals, alpha = 0.05) {
  boot_vals <- boot_vals[!is.na(boot_vals)]
  B <- length(boot_vals)
  if (B < 10 || is.na(theta_hat)) return(list(lower = NA, upper = NA, z0 = NA, a = NA, note = "insufficient data"))
  prop_less <- mean(boot_vals < theta_hat)
  if (prop_less <= 0) prop_less <- 1 / (2 * B)
  if (prop_less >= 1) prop_less <- 1 - 1 / (2 * B)
  z0 <- qnorm(prop_less)
  jv <- jack_vals[!is.na(jack_vals)]
  if (length(jv) < 3) { a <- 0; note <- "insufficient jackknife, a=0 (BC fallback)" }
  else {
    jm <- mean(jv); diffs <- jm - jv
    den <- 6 * (sum(diffs^2))^(1.5)
    a   <- if (den == 0) 0 else sum(diffs^3) / den
    note <- ""
  }
  z_lo <- qnorm(alpha/2); z_hi <- qnorm(1 - alpha/2)
  adj  <- function(zb) pnorm(z0 + (z0 + zb) / (1 - a * (z0 + zb)))
  a1 <- adj(z_lo); a2 <- adj(z_hi)
  list(lower = as.numeric(quantile(boot_vals, a1, na.rm = TRUE, names = FALSE)),
       upper = as.numeric(quantile(boot_vals, a2, na.rm = TRUE, names = FALSE)),
       z0 = z0, a = a, note = note)
}

# ============================================================
# Process one pooled dataset
# ============================================================

process_pooled <- function(ds) {
  label <- ds$label
  cat("\n##############################################################\n")
  cat("#  POOLED DATASET:", label, "  (", Sys.time(), ")\n")
  cat("##############################################################\n")
  
  # set config globals, then source 00 (faithful reproduction)
  country_label  <<- label
  data_path      <<- file.path(DATASET_DIR, ds$file)
  output_dir     <<- file.path(OUTPUT_DIR, label)
  cols_to_remove <<- ds$cols
  
  if (!file.exists(data_path)) { cat("  !!! data file missing:", data_path, "\n"); return(NULL) }
  source(file.path(RSCRIPT_DIR, "00_functions_data.R"))
  
  tr_path <- file.path(output_dir, "tuning_collect_results.rds")
  if (!file.exists(tr_path)) { cat("  !!! tuning rds missing:", tr_path, "\n"); return(NULL) }
  tuning_results <- readRDS(tr_path)
  
  blf <- tuning_results$best_logit_formula
  ofn <- tuning_results$best_of_nsets;      ofp <- tuning_results$best_of_ntreeperdiv
  oft <- tuning_results$best_of_ntreefinal; ofm <- tuning_results$best_of_mtry
  sc  <- tuning_results$best_svm_cost;      ss  <- tuning_results$best_svm_sigma
  kk  <- tuning_results$best_knn_kmax;      kd  <- tuning_results$best_knn_distance
  kn  <- tuning_results$best_knn_kernel
  
  fit_logit  <- function(dat) MASS::polr(formula = blf, data = dat, Hess = TRUE)
  pred_logit <- function(model, newdat, ol) list(
    pred = predict(model, newdata = newdat, type = "class"),
    prob_mat = align_prob_matrix(predict(model, newdata = newdat, type = "probs"), ol))
  fit_forest <- function(dat) { set.seed(FIT_SEED)
    ordinalForest::ordfor(depvar = "burden_score_ord", data = dat,
                          nsets = ofn, ntreeperdiv = ofp, ntreefinal = oft, mtry = ofm, perffunction = "probability") }
  pred_forest <- function(model, newdat, ol) { p <- predict(model, newdata = newdat)
  list(pred = p$ypred, prob_mat = align_prob_matrix(p$classprobs, ol)) }
  fit_svm <- function(dat) { set.seed(FIT_SEED)
    mildsvm::svor_exc(burden_score_ord ~ ., data = dat, cost = sc,
                      control = list(kernel = "radial", sigma = ss, scale = FALSE, max_steps = 5000)) }
  pred_svm <- function(model, newdat, ol) {
    x_new <- newdat %>% dplyr::select(-burden_score_ord)
    list(pred = predict(model, new_data = x_new, type = "class")$.pred_class,
         score_vec = extract_svm_score(predict(model, new_data = x_new, type = "raw"))) }
  fit_knn <- function(dat) kknn::train.kknn(burden_score_ord ~ ., data = dat,
                                            kmax = kk, distance = kd, kernel = kn, scale = FALSE)
  pred_knn <- function(model, newdat, ol) list(   # keep kknn cumulative prob as-is
    pred = predict(model, newdata = newdat, type = "raw"),
    prob_mat = align_prob_matrix(predict(model, newdata = newdat, type = "prob"), ol))
  
  model_specs <- list(
    list(name = "Ordinal Logistic Regression", fit = fit_logit,  pred = pred_logit,  mt = "prob"),
    list(name = "Ordinal Forest",              fit = fit_forest, pred = pred_forest, mt = "prob"),
    list(name = "Ordinal SVM",                 fit = fit_svm,    pred = pred_svm,    mt = "score"),
    list(name = "Ordinal KNN",                 fit = fit_knn,    pred = pred_knn,    mt = "prob")
  )
  
  ds_defs <- list(
    Train      = list(train = "train_ord",        eval = "train_ord"),
    Validation = list(train = "train_ord",        eval = "valid_ord"),
    Test       = list(train = "train_plus_valid", eval = "test_ord")
  )
  
  build_fixed <- function(spec, train_data, eval_data) {
    scaled <- make_scaled_train_valid(train_data, eval_data)
    tf <- scaled$train_final; ef <- scaled$valid_final
    ol <- levels(tf$burden_score_ord)
    yv <- factor(ef$burden_score_ord, levels = ol, ordered = TRUE)
    model <- spec$fit(tf); po <- spec$pred(model, ef, ol)
    list(metric_type = spec$mt, outcome_levels = ol, y_true = yv,
         pred_class = factor(po$pred, levels = ol, ordered = TRUE),
         prob_mat = if (spec$mt == "prob") po$prob_mat else NULL,
         score_vec = if (spec$mt == "score") po$score_vec else NULL)
  }
  
  cat("  Building fixed predictions... (", Sys.time(), ")\n")
  pred_store <- list()
  for (spec in model_specs) {
    pred_store[[spec$name]] <- list()
    for (dsn in names(ds_defs)) {
      tr <- get(ds_defs[[dsn]]$train, envir = globalenv())
      ev <- get(ds_defs[[dsn]]$eval,  envir = globalenv())
      res <- tryCatch(build_fixed(spec, tr, ev),
                      error = function(e) { message("    >>> ", spec$name, "/", dsn, " failed: ", e$message); NULL })
      if (!is.null(res)) pred_store[[spec$name]][[dsn]] <- res
    }
    if (length(pred_store[[spec$name]]) == 0) pred_store[[spec$name]] <- NULL
  }
  if (length(pred_store) == 0) { cat("  !!! all models failed for", label, "\n"); return(NULL) }
  
  metric_vec <- function(po, idx) {
    ol <- po$outcome_levels
    ys <- factor(po$y_true[idx], levels = ol, ordered = TRUE)
    ps <- factor(po$pred_class[idx], levels = ol, ordered = TRUE)
    cm <- tryCatch(caret::confusionMatrix(ps, ys), error = function(e) NULL)
    if (is.null(cm)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    if (po$metric_type == "prob")
      om <- tryCatch(calc_ordinal_metrics(ys, po$prob_mat[idx, , drop = FALSE]), error = function(e) NULL)
    else
      om <- tryCatch(calc_ordinal_metrics_from_score(ys, po$score_vec[idx]), error = function(e) NULL)
    if (is.null(om)) return(setNames(rep(NA_real_, length(metric_names)), metric_names))
    ev <- eval_ordinal_model("tmp", ys, ps, cm, om)
    setNames(as.numeric(ev[1, metric_names]), metric_names)
  }
  
  # --- original ---
  cat("  Original point estimates... (", Sys.time(), ")\n")
  orig_list <- list()
  for (m in names(pred_store)) for (dsn in names(pred_store[[m]])) {
    po <- pred_store[[m]][[dsn]]; v <- metric_vec(po, seq_along(po$y_true))
    orig_list[[length(orig_list)+1]] <- data.frame(Country=label, Model=m, Dataset=dsn,
                                                   as.list(v), check.names=FALSE, stringsAsFactors=FALSE)
  }
  original_df <- do.call(rbind, orig_list)
  
  # --- jackknife (PARALLEL via mclapply) ---
  cat("  Jackknife (parallel, ", N_CORES, " cores)... (", Sys.time(), ")\n", sep = "")
  jack_store <- list()
  for (m in names(pred_store)) {
    jack_store[[m]] <- list()
    for (dsn in names(pred_store[[m]])) {
      po <- pred_store[[m]][[dsn]]; n <- length(po$y_true)
      # each leave-one-out replicate computed in parallel
      rows <- mclapply(seq_len(n), function(i) metric_vec(po, setdiff(seq_len(n), i)),
                       mc.cores = N_CORES, mc.preschedule = TRUE)
      jm <- do.call(rbind, rows)
      colnames(jm) <- metric_names
      jack_store[[m]][[dsn]] <- jm
      cat("    ", m, "/", dsn, " jackknife done (n=", n, ", valid=", sum(complete.cases(jm)), ")\n", sep = "")
    }
  }
  
  # --- same-source bootstrap (PARALLEL via mclapply over b) ---
  cat("  Same-source bootstrap (", B_BOOT, " reps, parallel)... (", Sys.time(), ")\n", sep = "")
  new_boot <- list()
  for (m in names(pred_store)) {
    new_boot[[m]] <- list()
    for (dsn in names(pred_store[[m]])) {
      po <- pred_store[[m]][[dsn]]
      rows <- mclapply(seq_len(B_BOOT), function(b) {
        idx <- make_stratified_boot_index(po$y_true, seed = BOOT_SEED_BASE + b)
        metric_vec(po, idx)
      }, mc.cores = N_CORES, mc.preschedule = TRUE)
      bm <- do.call(rbind, rows)
      colnames(bm) <- metric_names
      new_boot[[m]][[dsn]] <- bm
    }
  }
  
  # --- BCa ---
  cat("  Assembling BCa... (", Sys.time(), ")\n")
  rows <- list()
  for (m in names(pred_store)) for (dsn in names(pred_store[[m]])) {
    bmat <- new_boot[[m]][[dsn]]; jmat <- jack_store[[m]][[dsn]]
    orow <- original_df[original_df$Model==m & original_df$Dataset==dsn, ]
    for (mt in metric_names) {
      res <- compute_bca(bmat[, mt], orow[[mt]], jmat[, mt])
      rows[[length(rows)+1]] <- data.frame(
        Country=label, Model=m, Dataset=dsn, Metric=mt,
        Original=round(orow[[mt]],4), BCa_Lower=round(res$lower,4), BCa_Upper=round(res$upper,4),
        z0=round(res$z0,4), a=round(res$a,4), Note=res$note, stringsAsFactors=FALSE)
    }
  }
  bca_table <- do.call(rbind, rows)
  
  saveRDS(list(bca_table=bca_table, original_df=original_df, new_boot=new_boot,
               jack_store=jack_store,
               seeds=list(FIT_SEED=FIT_SEED, BOOT_SEED_BASE=BOOT_SEED_BASE, B=B_BOOT)),
          file.path(output_dir, paste0(label, "_BCa_full.rds")))
  cat("  Saved:", file.path(output_dir, paste0(label, "_BCa_full.rds")), " (", Sys.time(), ")\n")
  
  bca_table
}

# ============================================================
# Run both pooled datasets
# ============================================================

cat("HPC BCa for pooled datasets started:", format(Sys.time()), "\n")
all_tables <- list()
for (ds in pooled_datasets) {
  res <- tryCatch(process_pooled(ds),
                  error = function(e) { message(">>> ", ds$label, " ERROR: ", e$message); NULL })
  if (!is.null(res)) all_tables[[ds$label]] <- res
}

cat("\n==================== DONE ====================\n")
cat("Pooled datasets completed:", paste(names(all_tables), collapse = ", "), "\n")
cat("Finished:", format(Sys.time()), "\n")