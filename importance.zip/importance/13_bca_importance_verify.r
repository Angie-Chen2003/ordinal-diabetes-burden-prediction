# ============================================================
# 13_bca_importance_verify.R  -- BCa for permutation importance (CHARLS verify)
# ------------------------------------------------------------
# VERIFICATION VERSION on CHARLS first (like 09 was), before scaling to all
# datasets. Upgrades the permutation-importance CIs from percentile to BCa.
#
# Importance (from 06) = base_orc - mean(permuted_orc over n_repeats=5), per
# (model x predictor), on the TEST set, model fit on train+valid (fixed).
# Permutation is DETERMINISTIC: 06 sets seed = 123 + b inside the importance
# function, so each replicate's shuffles are reproducible.
#
# BCa needs three pieces, per (model x predictor):
#   (1) bootstrap distribution of Importance  -> ALREADY on disk:
#         Output/<ds>/bootstrap_importance/importance_<b>.rds  (b = 1..1000)
#       We just read the Importance column. NO rerun.
#   (2) original point estimate  -> recompute on the FULL test set (no bootstrap)
#       with seed = 123 (the b=0 analogue of 06's 123+b), faithful to 06's logic.
#   (3) jackknife  -> NEW. Leave one test sample out, recompute Importance, with
#       a FIXED permutation seed (123) across all leave-one-out replicates, so
#       jackknife variation comes ONLY from the dropped sample, not reshuffling.
#
# Forest is seeded (FIT_SEED=2026) so its original/jackknife are self-consistent;
# note Excel's forest importance was unseeded, so forest may differ slightly.
# kknn cumulative prob kept as-is (consistent with the rest of the pipeline).
#
# Usage: setwd(".../R_script"); source("13_bca_importance_verify.r")
# ============================================================

suppressMessages({
  library(readxl); library(dplyr); library(caret); library(pROC)
  library(MASS); library(ordinalForest); library(mildsvm); library(kknn)
  library(writexl)
})

# ---- config for CHARLS (single-country) ----
country_label  <<- "CHARLS"
data_path      <<- "~/Documents/Jeannette/HPC_code/Dataset/CHARLS_final.xlsx"
output_dir     <<- "~/Documents/Jeannette/HPC_code/Output/CHARLS"
cols_to_remove <<- c("social_eco_ppp", "country")
RSCRIPT_DIR    <- "~/Documents/Jeannette/HPC_code/R_script"

FIT_SEED       <- 2026
PERM_SEED      <- 123   # original & jackknife permutation seed (06's b=0 analogue)
N_REPEATS      <- 5     # match 06 / importance_n_repeats
B_BOOT         <- 1000

setwd(RSCRIPT_DIR)
source(file.path(RSCRIPT_DIR, "00_functions_data.r"))  # builds train_plus_valid, test_ord, helpers

tuning_results <- readRDS(file.path(output_dir, "tuning_collect_results.rds"))
blf <- tuning_results$best_logit_formula
ofn <- tuning_results$best_of_nsets;      ofp <- tuning_results$best_of_ntreeperdiv
oft <- tuning_results$best_of_ntreefinal; ofm <- tuning_results$best_of_mtry
sc  <- tuning_results$best_svm_cost;      ss  <- tuning_results$best_svm_sigma
kk  <- tuning_results$best_knn_kmax;      kd  <- tuning_results$best_knn_distance
kn  <- tuning_results$best_knn_kernel

# ============================================================
# ORC-from-score (identical to 06)
# ============================================================
extract_svm_score <- function(raw_pred) {
  raw_df <- as.data.frame(raw_pred)
  if (".pred" %in% names(raw_df)) return(as.numeric(raw_df$.pred))
  nc <- names(raw_df)[sapply(raw_df, is.numeric)]
  if (length(nc) == 0) stop("No numeric raw-score column.")
  as.numeric(raw_df[[nc[1]]])
}
calc_orc_from_score <- function(y_true, score_vec) {
  y <- as.numeric(y_true); s <- as.numeric(score_vec)
  if (all(is.na(s))) return(NA_real_)
  cls <- sort(unique(y[!is.na(y)])); if (length(cls) < 2) return(NA_real_)
  au <- c()
  for (i in 1:(length(cls)-1)) for (j in (i+1):length(cls)) {
    idx <- which(y %in% c(cls[i], cls[j]))
    yb  <- ifelse(y[idx] == cls[j], 1, 0); sv <- s[idx]
    keep <- !is.na(sv); yb <- yb[keep]; sv <- sv[keep]
    if (length(unique(yb)) == 2 && length(unique(sv)) > 1)
      au <- c(au, as.numeric(pROC::auc(response = yb, predictor = sv, quiet = TRUE)))
  }
  if (length(au) == 0) return(NA_real_) else mean(au, na.rm = TRUE)
}
predict_score_for_importance <- function(model, new_data, y_true, model_type) {
  yl <- levels(y_true)
  if (model_type == "logit") {
    pr <- align_prob_matrix(predict(model, newdata = new_data, type = "probs"), yl)
    as.numeric(pr %*% seq_along(yl))
  } else if (model_type == "forest") {
    pd <- predict(model, newdata = new_data)
    pr <- align_prob_matrix(pd$classprobs, yl); as.numeric(pr %*% seq_along(yl))
  } else if (model_type == "svm") {
    extract_svm_score(predict(model, new_data = new_data, type = "raw"))
  } else if (model_type == "knn") {
    pr <- align_prob_matrix(predict(model, newdata = new_data, type = "prob"), yl)
    as.numeric(pr %*% seq_along(yl))
  } else stop("bad model_type")
}

# Importance for a given test_data/y (deterministic via seed). Returns named vec
# Importance per predictor. Permutation uses set.seed(perm_seed) ONCE then 5x
# shuffles per predictor -- faithful to 06's permutation_importance_orc.
importance_vec <- function(model, model_type, test_data, y_true, predictor_cols,
                           n_repeats = N_REPEATS, perm_seed = PERM_SEED) {
  set.seed(perm_seed)
  y_true <- factor(y_true, levels = levels(y_true), ordered = TRUE)
  base_score <- predict_score_for_importance(model, test_data, y_true, model_type)
  base_orc   <- calc_orc_from_score(y_true, base_score)
  imp <- sapply(predictor_cols, function(vv) {
    pv <- numeric(n_repeats)
    for (rr in seq_len(n_repeats)) {
      pd <- test_data; pd[[vv]] <- sample(pd[[vv]])
      pv[rr] <- calc_orc_from_score(y_true, predict_score_for_importance(model, pd, y_true, model_type))
    }
    base_orc - mean(pv, na.rm = TRUE)
  })
  setNames(as.numeric(imp), predictor_cols)
}

# ============================================================
# Fit models on train+valid (forest/svm seeded), evaluate on test
# ============================================================
scaled <- make_scaled_train_test(train_plus_valid, test_ord)
train_final <- scaled$train_final; test_final <- scaled$test_final
y_test <- factor(test_final$burden_score_ord, levels = levels(train_final$burden_score_ord), ordered = TRUE)
predictor_cols <- setdiff(names(test_final), "burden_score_ord")
cat("Predictors (", length(predictor_cols), "):", paste(predictor_cols, collapse=", "), "\n")

model_logit  <- MASS::polr(formula = blf, data = train_final, Hess = TRUE)
set.seed(FIT_SEED)
model_forest <- ordinalForest::ordfor(depvar="burden_score_ord", data=train_final,
                                      nsets=ofn, ntreeperdiv=ofp, ntreefinal=oft, mtry=ofm, perffunction="probability")
set.seed(FIT_SEED)
model_svm <- mildsvm::svor_exc(burden_score_ord ~ ., data=train_final, cost=sc,
                               control=list(kernel="radial", sigma=ss, scale=FALSE, max_steps=5000))
model_knn <- kknn::train.kknn(burden_score_ord ~ ., data=train_final,
                              kmax=kk, distance=kd, kernel=kn, scale=FALSE)

models <- list(
  list(name="Ordinal Logistic Regression", m=model_logit,  type="logit",  needs_y=TRUE),
  list(name="Ordinal Forest",              m=model_forest, type="forest", needs_y=TRUE),
  list(name="Ordinal SVM",                 m=model_svm,    type="svm",    needs_y=FALSE),
  list(name="Ordinal KNN",                 m=model_knn,    type="knn",    needs_y=TRUE)
)
# SVM importance uses data WITHOUT outcome col (06 convention)
test_no_y <- test_final %>% dplyr::select(-burden_score_ord)

get_test_data <- function(spec) if (spec$needs_y) test_final else test_no_y

# ============================================================
# (2) ORIGINAL importance (full test, perm seed 123)
# ============================================================
cat("\nComputing ORIGINAL importance (perm seed", PERM_SEED, ")...\n")
orig_imp <- list()
for (spec in models) {
  iv <- importance_vec(spec$m, spec$type, get_test_data(spec), y_test, predictor_cols)
  for (vv in predictor_cols)
    orig_imp[[length(orig_imp)+1]] <- data.frame(Model=spec$name, Predictor=vv,
                                                 Importance_Original=iv[[vv]], stringsAsFactors=FALSE)
}
orig_imp_df <- do.call(rbind, orig_imp)

# Verify vs Excel original importance (07 export), if available
excel_path <- file.path(output_dir, "CHARLS_all_final_tables.xlsx")
if (file.exists(excel_path)) {
  ex <- tryCatch(read_xlsx(excel_path, sheet="05_Variable_Importance_With_CI"), error=function(e) NULL)
  if (!is.null(ex)) {
    cat("\n--- ORIGINAL importance: recomputed vs Excel ---\n")
    for (i in seq_len(nrow(orig_imp_df))) {
      r <- orig_imp_df[i, ]
      er <- ex[ex$Model==r$Model & ex$Predictor==r$Predictor, ]
      if (nrow(er) >= 1) {
        mine <- round(r$Importance_Original, 3); theirs <- round(as.numeric(er$Importance[1]), 3)
        fl <- if (is.na(mine)||is.na(theirs)) "?" else if (abs(mine-theirs)<=0.01) "OK" else
          if (r$Model=="Ordinal Forest") "forest-expected" else "<<< CHECK"
        cat(sprintf("  %-28s %-18s rebuilt=%+.3f excel=%+.3f  %s\n", r$Model, r$Predictor, mine, theirs, fl))
      }
    }
  }
}

# ============================================================
# (1) BOOTSTRAP distribution from disk (no rerun)
# ============================================================
cat("\nReading bootstrap importance (1000 reps from disk)...\n")
imp_dir <- file.path(output_dir, "bootstrap_importance")
files <- file.path(imp_dir, paste0("importance_", seq_len(B_BOOT), ".rds"))
files <- files[file.exists(files)]
boot_all <- bind_rows(lapply(files, readRDS))
cat("  read", length(files), "bootstrap files,", nrow(boot_all), "rows total.\n")

# ============================================================
# (3) JACKKNIFE (NEW): leave-one-out, FIXED permutation seed
# ============================================================
cat("\nComputing jackknife importance (fixed perm seed)... this is the slow part.\n")
n <- length(y_test)
jack_store <- list()  # jack_store[[model]][[predictor]] = numeric(n)
for (spec in models) {
  td_full <- get_test_data(spec)
  jmat <- matrix(NA_real_, n, length(predictor_cols), dimnames=list(NULL, predictor_cols))
  for (i in seq_len(n)) {
    keep <- setdiff(seq_len(n), i)
    iv <- importance_vec(spec$m, spec$type, td_full[keep, , drop=FALSE],
                         factor(y_test[keep], levels=levels(y_test), ordered=TRUE),
                         predictor_cols)
    jmat[i, ] <- iv
  }
  jack_store[[spec$name]] <- jmat
  cat("  ", spec$name, "jackknife done.\n")
}

# ============================================================
# BCa assembly
# ============================================================
compute_bca <- function(boot_vals, theta_hat, jack_vals, alpha=0.05) {
  boot_vals <- boot_vals[!is.na(boot_vals)]; B <- length(boot_vals)
  if (B < 10 || is.na(theta_hat)) return(list(lower=NA, upper=NA, z0=NA, a=NA, note="insufficient"))
  pl <- mean(boot_vals < theta_hat); if (pl<=0) pl <- 1/(2*B); if (pl>=1) pl <- 1-1/(2*B)
  z0 <- qnorm(pl); jv <- jack_vals[!is.na(jack_vals)]
  if (length(jv) < 3) { a <- 0; note <- "insufficient jackknife" }
  else { jm <- mean(jv); df <- jm-jv; den <- 6*(sum(df^2))^1.5; a <- if (den==0) 0 else sum(df^3)/den; note <- "" }
  zl <- qnorm(alpha/2); zh <- qnorm(1-alpha/2); adj <- function(zb) pnorm(z0+(z0+zb)/(1-a*(z0+zb)))
  list(lower=as.numeric(quantile(boot_vals, adj(zl), na.rm=TRUE, names=FALSE)),
       upper=as.numeric(quantile(boot_vals, adj(zh), na.rm=TRUE, names=FALSE)), z0=z0, a=a, note=note)
}

cat("\nAssembling BCa for importance...\n")
rows <- list()
for (spec in models) {
  jmat <- jack_store[[spec$name]]
  for (vv in predictor_cols) {
    bv <- boot_all$Importance[boot_all$Model==spec$name & boot_all$Predictor==vv]
    th <- orig_imp_df$Importance_Original[orig_imp_df$Model==spec$name & orig_imp_df$Predictor==vv]
    res <- compute_bca(bv, th, jmat[, vv])
    rows[[length(rows)+1]] <- data.frame(Country="CHARLS", Model=spec$name, Predictor=vv,
                                         Importance=round(th,4), BCa_Lower=round(res$lower,4), BCa_Upper=round(res$upper,4),
                                         z0=round(res$z0,4), a=round(res$a,4), Note=res$note, stringsAsFactors=FALSE)
  }
}
bca_imp <- do.call(rbind, rows)

cat("\n========== BCa importance (CHARLS) ==========\n")
print(bca_imp, row.names=FALSE)

saveRDS(list(bca_imp=bca_imp, orig=orig_imp_df, jack=jack_store),
        file.path(output_dir, "CHARLS_importance_BCa.rds"))
cat("\nSaved: ", file.path(output_dir, "CHARLS_importance_BCa.rds"), "\n")
cat("\nVERIFY: (1) recomputed original ~ Excel importance (forest excepted)\n")
cat("        (2) BCa CIs look sensible (lower<=Importance<=upper, no wild values)\n")
cat("If good, I'll scale to all 10 datasets (and decide local vs HPC for big ones).\n")